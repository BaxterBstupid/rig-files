#!/usr/bin/env python3
"""
rs_gate.py  v7 -- turn a RealityScan rs_gate.html report into PASS / FAIL lines.  Used by rs_merge.py; runs standalone too.

    python rs_gate.py <report.html> --stage report|align|lidar|merge|mesh [--images <images_dir>] [--label text]
    python rs_gate.py --selftest

Report format (rs_gate.html v5):  COMP|name|cams|points|cpsUsed|meanErr|medianErr|maxErr|georef|metric   (one per component)
                                  CAM|name.ext|x|y|z|priorError3D|f|imagePath|width|height                 (selected component only; LSP views are 240x150 / 480x300)
Exit 0 = PASS, 1 = FAIL, 2 = report unreadable / template not evaluated.
Gates (reference section 3 + audit 2026-10-07 section 5, thresholds revised on the S0 numbers of 2026-10-07):
  align : ONE component; cameras >= 90 % of photos; mean reproj <= 2.0 px (S0 measured 1.52 with the 3 px cap binding);
          max <= 3.0 px; photo priorError3D median <= 0.10 m (frame check)
  lidar : exactly one photo component + one Laserscan component, equal counts; whichever block the CAM lines belong to
          must sit within 0.10 m of its priors (LSP block measured 4.81 m off in the first-try project)
  merge : ONE component holding >= 90 % of 2N cameras; control points used >= 6; mean reproj <= 3 px
  mesh  : one component present (the mesh itself is judged by the eye)
Informational at every stage: georeferenced / metric flags per component (S0 showed photos georef=True/metric=False
vs LSPs georef=False/metric=True -- the asymmetry suspected of blocking the merge).
"""
import sys, os, re, argparse, statistics, tempfile, io, contextlib

NAN = float("nan")
ALIGN_MEAN_PX, ALIGN_MAX_PX, FRAME_M, MERGE_MEAN_PX, MIN_CPS = 2.0, 3.0, 0.10, 3.0, 6

def num(s, default=NAN):
    try: return float(str(s).strip())
    except Exception: return default

def parse(text):
    comps, cams, leftovers = [], [], 0
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("COMP|"):
            f = [x.strip() for x in line.split("|")]
            if "$" in line: leftovers += 1
            g = lambda k, d=NAN: num(f[k]) if len(f) > k else d
            comps.append(dict(name=f[1] if len(f) > 1 else "?", cams=int(g(2, 0) if g(2, 0) == g(2, 0) else 0),
                              points=int(g(3, 0) if g(3, 0) == g(3, 0) else 0), cps=int(g(4, 0) if g(4, 0) == g(4, 0) else 0),
                              mean=g(5), median=g(6), max=g(7), georef=f[8] if len(f) > 8 else "?", metric=f[9] if len(f) > 9 else "?"))
        elif line.startswith("CAM|"):
            f = [x.strip() for x in line.split("|")]
            if "$" in line: leftovers += 1; continue
            if len(f) >= 7: cams.append(dict(name=f[1], x=num(f[2]), y=num(f[3]), z=num(f[4]), prior3d=num(f[5]), f=num(f[6]), path=f[7] if len(f) > 7 else "",
                                             w=int(num(f[8], 0)) if len(f) > 8 and num(f[8]) == num(f[8]) else 0, h=int(num(f[9], 0)) if len(f) > 9 and num(f[9]) == num(f[9]) else 0))
    return comps, cams, leftovers

def fmt(v): return "%.2f" % v if v == v else "n/a"

def kind_of(name):
    n = name.lower()
    return "photo" if n.endswith(".jpg") else ("LSP" if n.endswith(".lsp") else "other")

def gate(comps, cams, stage, n_photos):
    fails = []
    def need(cond, msg):
        if not cond: fails.append(msg)
    photo_comp = [c for c in comps if not c["name"].lower().startswith("laserscan")]
    laser_comp = [c for c in comps if c["name"].lower().startswith("laserscan")]
    big = max(comps, key=lambda c: c["cams"]) if comps else None
    pe = [c["prior3d"] for c in cams if c["prior3d"] == c["prior3d"] and kind_of(c["name"]) == "photo"]
    pl = [c["prior3d"] for c in cams if c["prior3d"] == c["prior3d"] and kind_of(c["name"]) == "LSP"]
    if stage == "report":
        pass
    elif stage == "align":
        need(len(comps) == 1, "expected ONE component, got %d" % len(comps))
        if big and n_photos: need(big["cams"] >= 0.9 * n_photos, "cameras %d < 90%% of %d photos" % (big["cams"], n_photos))
        if big and big["mean"] == big["mean"]:
            need(big["mean"] <= ALIGN_MEAN_PX, "mean reprojection %.2f px > %.1f (calibration / blur -- a bundle problem)" % (big["mean"], ALIGN_MEAN_PX))
            need(big["max"] <= ALIGN_MAX_PX, "max reprojection %.2f px > %.1f" % (big["max"], ALIGN_MAX_PX))
        if pe: need(statistics.median(pe) <= FRAME_M, "photo block floated: median priorError3D %.3f m > %.2f" % (statistics.median(pe), FRAME_M))
    elif stage == "lidar":
        mergedc = [c for c in comps if n_photos and c["cams"] >= 1.8 * n_photos]
        if mergedc:   # [OBS 2026-10-08] RS creates the merged component as a NEW component and keeps the two source blocks beside it
            fails.append("MERGED: component %r holds %d cameras (~2 x %d photos), georef %s metric %s; the %d source block(s) remain beside it (RS keeps them) -- go straight to 'mesh' with this tag"
                         % (mergedc[0]["name"], mergedc[0]["cams"], n_photos, mergedc[0]["georef"], mergedc[0]["metric"], len(comps) - 1))
            return fails   # reported as FAIL of the lidar gate on purpose: the operator must read it
        need(len(laser_comp) == 1, "expected one Laserscan component, got %d" % len(laser_comp))
        need(len(photo_comp) == 1, "expected one photo component, got %d (duplicates = aligned more than once: documented outcome 2)" % len(photo_comp))
        if laser_comp and photo_comp:
            need(laser_comp[0]["cams"] == photo_comp[0]["cams"], "LSP count %d != photo count %d" % (laser_comp[0]["cams"], photo_comp[0]["cams"]))
        if pe: need(statistics.median(pe) <= FRAME_M, "photo block floated: median priorError3D %.3f m > %.2f" % (statistics.median(pe), FRAME_M))
        if pl: need(statistics.median(pl) <= FRAME_M, "LSP block floated: median priorError3D %.3f m > %.2f (whole-block offset from its own priors)" % (statistics.median(pl), FRAME_M))
    elif stage == "merge":
        if big and n_photos and big["cams"] >= 1.8 * n_photos and len(comps) > 1:
            print("  NOTE: merged component %r (%d cams) with %d source block(s) beside it -- RS keeps the sources; mesh selects the maximal component" % (big["name"], big["cams"], len(comps) - 1))
        else:
            need(len(comps) == 1, "still %d components -- not merged" % len(comps))
        if big and n_photos: need(big["cams"] >= 0.9 * 2 * n_photos, "merged component has %d cams, expected ~%d" % (big["cams"], 2 * n_photos))
        if big:
            need(big["cps"] >= MIN_CPS, "control points used %d < %d" % (big["cps"], MIN_CPS))
            if big["mean"] == big["mean"]: need(big["mean"] <= MERGE_MEAN_PX, "mean reprojection %.2f px > %.1f" % (big["mean"], MERGE_MEAN_PX))
    elif stage == "mesh":
        need(len(comps) >= 1, "no component")
    else:
        raise SystemExit("unknown stage %s" % stage)
    return fails

def run(report, stage, images, label=""):
    try:
        raw = open(report, "r", encoding="utf-8", errors="replace").read()
    except OSError as e:
        print("GATE FAIL: cannot read report:", e); return 2
    text = re.sub(r"<[^>]+>", "\n", raw).lstrip("﻿")
    if not raw.strip():
        print("GATE FAIL: report is empty (0 bytes) -- RealityScan rejected the template; read the RS| lines above"); return 2
    if "RSGATE|" not in text:
        print("GATE FAIL: report has no RSGATE header -- template not evaluated? First 300 chars:\n", text[:300]); return 2
    if re.search(r"^\$(IterateComponents|ExportCameras)\(", text, re.M):
        print("GATE FAIL: template functions were written out literally -- RealityScan did not evaluate the template"); return 2
    comps, cams, leftovers = parse(text)
    n_photos = len([f for f in os.listdir(images) if f.lower().endswith(".jpg")]) if images and os.path.isdir(images) else None
    print("=== rs_gate %s %s  report=%s" % (stage, label, os.path.basename(report)))
    print("components: %d   cameras listed: %d   photos on disk: %s" % (len(comps), len(cams), n_photos))
    if leftovers: print("  WARNING: %d line(s) still contain $(...) -- a template function did not evaluate; stats may be n/a" % leftovers)
    for c in comps:
        print("  %-24s cams %5d  points %8d  CPs %2d  reproj mean %s med %s max %s px  georef %s metric %s"
              % (c["name"], c["cams"], c["points"], c["cps"], fmt(c["mean"]), fmt(c["median"]), fmt(c["max"]), c["georef"], c["metric"]))
    groups = {}
    for c in cams:
        if c["prior3d"] == c["prior3d"]: groups.setdefault(kind_of(c["name"]), []).append(c["prior3d"])
    for kind, v in sorted(groups.items()):
        v = sorted(v)
        print("  frame check (%s cameras of the selected component): priorError3D median %.3f m  p90 %.3f m  max %.3f m  (n=%d)"
              % (kind, statistics.median(v), v[int(0.9 * (len(v) - 1))], v[-1], len(v)))
    if cams and cams[0]["f"] == cams[0]["f"]:
        print("  focal check: f=%.4f x 36 = %.2f mm (bundle FocalLength35mm 15.914)" % (cams[0]["f"], cams[0]["f"] * 36))
    gset = {(c["georef"], c["metric"]) for c in comps}
    if len(comps) >= 2 and len(gset) > 1:
        print("  NOTE: components differ in georeferenced/metric flags %s -- RealityScan treats them as different kinds of block" % sorted(gset))
    fails = gate(comps, cams, stage, n_photos)
    if not comps and stage != "report": fails.append("no COMP lines parsed")
    if leftovers and stage in ("align", "merge"):
        fails.append("component stats did not evaluate ($(...) left in a COMP line) -- fix rs_gate.html, then re-run the 'report' stage on this stage's .rsproj")
    if fails:
        print("GATE FAIL (%s):" % stage)
        for m in fails: print("  - " + m)
        return 1
    print("GATE PASS (%s)" % stage)
    return 0

def _cases():
    hdr = "﻿\r\n\r\n\r\n\r\nRSGATE|v5|2026-10-07\r\n"
    c0 = "COMP|Component 0|900|39515|0|1.52|1.53|3.00|True|False\r\n"
    ls = "COMP|Laserscan component|900|622935|0|0|0|0|False|True\r\n"
    cams_photo = "".join("CAM|img_%d.jpg|0|0|0|0.031|0.4420619606971741\r\n" % i for i in range(900))
    cams_lsp_ok = "".join("CAM|img_%d_1_color.lsp|0|0|0|0.000|0.4420619606971741\r\n" % i for i in range(900))
    cams_lsp_float = "".join("CAM|img_%d_1_color.lsp|0|0|0|4.814|0.4420619606971741\r\n" % i for i in range(900))
    merged = "COMP|Component 0|1800|662450|6|1.7|1.2|2.9|True|True\r\n"
    return [
        ("S1 good",            hdr + c0 + cams_photo + "END", "align", 0),
        ("S1 floated",         hdr + c0 + cams_photo.replace("0.031", "0.600") + "END", "align", 1),
        ("S1 split",           hdr + c0.replace("|900|", "|640|") + "COMP|Component 1|260|9000|0|0.9|0.7|2.9|True|False\r\n" + cams_photo + "END", "align", 1),
        ("S1 bad calib",       hdr + c0.replace("1.52", "2.40") + cams_photo + "END", "align", 1),
        ("S2 imported ok",     hdr + c0 + ls + cams_lsp_ok + "END", "lidar", 0),
        ("S2 outcome 2",       hdr + c0 + ls + c0.replace("Component 0", "Component 0 (1)") + ls.replace("Laserscan component", "Component 1") + cams_photo + "END", "lidar", 1),
        ("S2 LSP float",       hdr + c0 + ls + cams_lsp_float + "END", "lidar", 1),
        ("S3 merged",          hdr + merged + cams_photo + "END", "merge", 0),
        ("S3 not merged",      hdr + c0 + ls + "END", "merge", 1),
        ("S3 few CPs",         hdr + merged.replace("|6|", "|4|") + "END", "merge", 1),
        ("S4 mesh",            hdr + merged + "END", "mesh", 0),
        ("S0 first try",       hdr + c0 + ls + c0.replace("Component 0", "Component 0 (1)") + ls.replace("Laserscan component", "Component 1") + cams_lsp_float + "END", "report", 0),
        ("empty report",       "", "align", 2),
        ("literal template",   "RSGATE|v5|$(dateTime)\r\n$IterateComponents(COMP|...)\r\nEND", "align", 2),
        ("nested unevaluated", hdr + "COMP|Component 0|900|$ComponentInfo(x,$(componentPointCount))\r\n" + cams_photo + "END", "align", 1),
        ("garbage",            "garbage", "align", 2),
    ]

def selftest(verbose=True):
    ok = True
    for name, txt, stage, want in _cases():
        with tempfile.NamedTemporaryFile("w", suffix=".html", delete=False, encoding="utf-8", newline="") as fh:
            fh.write(txt); p = fh.name
        try:
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf): rc = run(p, stage, None, "selftest")
        finally:
            os.unlink(p)
        ok &= (rc == want)
        if verbose: print("  selftest %-20s %-6s expect %d got %d %s" % (name, stage, want, rc, "ok" if rc == want else "MISMATCH"))
    if verbose: print("SELFTEST", "PASS" if ok else "FAIL")
    return ok

def selftest_quiet(): return selftest(verbose=False)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("report", nargs="?"); ap.add_argument("--stage", default=None)
    ap.add_argument("--images", default=None); ap.add_argument("--label", default="")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest: sys.exit(0 if selftest() else 1)
    if not a.report or not a.stage: ap.error("report and --stage required (or --selftest)")
    sys.exit(run(a.report, a.stage, a.images, a.label))
