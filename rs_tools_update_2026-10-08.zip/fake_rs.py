#!/usr/bin/env python3
"""
fake_rs.py -- a stand-in for RealityScan.exe that behaves like RealityScan 2.1.1.119166 at the command line,
encoding ONLY what was observed on Shadow (2026-10-07) or read in the RS help / Epic docs.  It exists so the
merge pipeline (rs_merge.py + rs_gate.py + rs_gate.html) can be run end to end in a sandbox, in every known
scenario, before a single real run.  Each rule carries its source:  [OBS] observed live, [DOC] documented,
[ASSUMED] a guess that the first real run of that stage must confirm.

Usage (what rs_merge.py does):   python fake_rs.py -stdConsole -headless -silent dir -set k=v -load p.rsproj deleteAutosave ...
Scenario (env FAKE_RS_SCENARIO):  good | outcome2 | float | lsp_float
  good      align after LiDAR import leaves exactly photo + Laserscan components; CP import + align / mergeComponents -> ONE component
  outcome2  any align after the import re-creates both blocks ("Component 0 (1)", "Component 1")  [OBS 2026-10-06/07]
  float     photo block drifts 0.6 m from its XMP priors after align                              (audit risk 4-A)
  lsp_float LSP block sits 4.81 m from its own priors                                               [OBS 2026-10-07 S0]
GUI lock:  a file <project>.lock beside the project = "already open in another instance"           [OBS 2026-10-07]
"""
import sys, os, re, json, time, random

VERSION = "2.1.1.119166"
E_LOCKED = -2113929193      # 0x82000017  [OBS] load while the GUI holds the project
E_INVALID = -2147024809     # 0x80070057  [OBS] exportReport template error
SCEN = os.environ.get("FAKE_RS_SCENARIO", "good")

def out(s): print(s, flush=True)

class State:
    def __init__(self):
        self.images = []          # list of dict(name, ext, kind, stamp)
        self.comps = []           # list of dict(name, guid, cams(list of image idx), points, mean, median, max, georef, metric, cps)
        self.selected = None      # component name
        self.sel_images = set()
        self.locked = set()
        self.settings = {"appQuitOnError": "false", "sfmEnableCameraPrior": "false"}
        self.cps = 0              # control points imported (count)
        self.models = []
        self.project = None
        self.guid_n = 0
    def guid(self):
        self.guid_n += 1
        return "{%08X-0000-0000-0000-%012X}" % (self.guid_n, random.randrange(1 << 40))

def photo_comp(st, name, cams, prior_err):
    st.guid_n += 1
    return dict(name=name, guid=st.guid(), cams=cams, points=39515 if name == "Component 0" else 39216,
                mean=1.52, median=1.53, max=3.00, georef="True" if st.settings.get("sfmEnableCameraPrior", "false") == "true" else "False",
                metric="False", cps=0, prior=prior_err)

def lsp_comp(st, name, cams, prior_err):
    return dict(name=name, guid=st.guid(), cams=cams, points=622935, mean=0.0, median=0.0, max=0.0,
                georef="False", metric="True", cps=0, prior=prior_err)

# ---------------------------------------------------------------- report engine [DOC + OBS]
SETS = {"IterateComponents": "IteratorsFunctionSet", "SelectComponent": "IteratorsFunctionSet",
        "ComponentInfo": "ComponentFunctionSet", "ComponentStats": "ComponentFunctionSet",
        "ExportCameras": "SfmExportFunctionSet", "ExportProjectInfo": "ProjectInformationExportFunctionSet"}

class TemplateError(Exception): pass

def match_paren(s, i):
    depth = 0
    for j in range(i, len(s)):
        if s[j] == "(": depth += 1
        elif s[j] == ")":
            depth -= 1
            if depth == 0: return j
    raise TemplateError("unbalanced parentheses")

def linecol(s, pos):
    line = s.count("\n", 0, pos) + 1
    col = pos - (s.rfind("\n", 0, pos) + 1) + 1
    return line, col

def subst(body, scope):
    def rep(m):
        name = m.group(1).strip()
        if name in scope: return str(scope[name])
        return ""   # [ASSUMED] unknown variable prints empty; real engine behaviour not observed
    return re.sub(r"\$\(([^()]*)\)", rep, body)

def evaluate(tpl, st, tpl_path):
    text = tpl.lstrip("﻿")
    using = set(re.findall(r'\$Using\(\s*"RealityScan\.Report\.(\w+)"\s*\)', text))
    text = re.sub(r'\$Using\([^)]*\)', "", text)
    def ev(s, scope):
        o = []; i = 0
        while True:
            m = re.search(r"\$([A-Za-z]\w*)\(", s[i:])
            if not m: o.append(subst(s[i:], scope)); return "".join(o)
            start = i + m.start(); fn = m.group(1); lp = i + m.end() - 1
            o.append(subst(s[i:start], scope))
            rp = match_paren(s, lp)
            inner = s[lp + 1:rp]
            if fn not in SETS: raise TemplateError("unknown function '$%s'" % fn)           # [ASSUMED]
            if SETS[fn] not in using: raise TemplateError("function '$%s' needs $Using( \"RealityScan.Report.%s\" )" % (fn, SETS[fn]))  # [OBS] 0-byte report without $Using
            if fn in ("ComponentInfo", "ComponentStats", "SelectComponent"):
                k = inner.find(",")
                arg = inner if (k < 0 or fn == "SelectComponent") else inner[:k]
                body = "" if k < 0 else inner[k + 1:]
                a = arg.strip()
                if a.startswith("$"):
                    ln, col = linecol(s, lp + 1 + inner.find(a))
                    raise TemplateError("at [%d,%d]: identifier expected but '$' found\nerror in '%s' at [%d,%d]: a GUID in format \"{134...-..}\" was expected" % (ln, col, tpl_path, ln, col))  # [OBS]
                if not re.match(r"^[A-Za-z_]\w*$", a) and not re.match(r"^\{[0-9A-Fa-f-]+\}$", a):
                    ln, col = linecol(s, lp + 1); raise TemplateError("at [%d,%d]: identifier expected" % (ln, col))
                guid = scope.get(a, a)
                comp = next((c for c in st.comps if c["guid"] == guid), None)
                if fn == "SelectComponent":
                    o.append("")     # [OBS] does NOT change which component $ExportCameras writes
                elif comp is None:
                    o.append("")
                else:
                    sc = dict(scope)
                    if fn == "ComponentInfo":
                        sc.update(componentName=comp["name"], componentCameraCount=len(comp["cams"]), componentPointCount=comp["points"],
                                  componentControlPointCountUsed=comp["cps"], componentConstraintCountUsed=0)
                    else:
                        sc.update(componentMeanError="%.6f" % comp["mean"], componentMedianError="%.6f" % comp["median"],
                                  componentMaximalError="%.6f" % comp["max"], componentIsGeoreferenced=comp["georef"],
                                  componentMetric=comp["metric"], componentTotalProjection=0, componentAverageTrackLength=0, componentAlignmentTime=0)
                    o.append(ev(body, sc))
            elif fn == "IterateComponents":
                for c in st.comps:
                    sc = dict(scope); sc.update(componentGUID=c["guid"], componentName=c["name"], componentCamerasCount=len(c["cams"]))
                    o.append(ev(inner, sc))
            elif fn == "ExportCameras":
                comp = next((c for c in st.comps if c["name"] == st.selected), None)   # [OBS] application selection only
                if comp is None and st.comps: comp = st.comps[0]
                for idx in (comp["cams"] if comp else []):
                    im = st.images[idx]
                    sc = dict(scope); w, h = (1920, 1200) if im["kind"] == "photo" else ((240, 150) if idx % 2 else (480, 300))   # [OBS 2026-10-08] LSP views rendered at 1/8 or 1/4
                    sc.update(width=w, height=h, px="-2.0311e-002", py="-2.8365e-002")
                    sc.update(imageName=im["name"], imageExt="." + im["ext"], index=idx,   # [OBS 2026-10-08] imageExt carries the dot (export example DSC_0010.JPG); template's "$(imageName).$(imageExt)" yields a double dot x="%.15g" % im["x"], y="%.15g" % im["y"], z="%.15g" % im["z"],
                                               priorError3D="%.15g" % (comp["prior"] + random.uniform(0, 0.04)), f="0.4420619606971741", imagePath=im.get("path", ""))  # [OBS] f = 15.914/36
                    o.append(ev(inner, sc))
            elif fn == "ExportProjectInfo":
                sc = dict(scope); sc.update(projectName=os.path.basename(st.project or "Untitled"), imageCount=len(st.images), componentCount=len(st.comps))
                o.append(ev(inner, sc))
            i = rp + 1
    return ev(text, {"dateTime": time.strftime("%Y-%m-%d %H:%M:%S"), "appVersion": VERSION})

# ---------------------------------------------------------------- CLI
def main(argv):
    out("RealityScan %s (c) 2026 Epic Games, Inc.  [fake_rs scenario=%s]" % (VERSION, SCEN))
    out("Using 8 CPU cores and process %d." % os.getpid())
    st = State(); quit_on_error = False
    i = 0
    def params(n):
        nonlocal i
        p = []
        while len(p) < n and i + 1 < len(argv) and not argv[i + 1].startswith("-"):
            i += 1; p.append(argv[i])
        return p
    def fail(msg, code):
        out("Processing failed: %s" % msg)
        if quit_on_error:
            out("Executing command 'quit' (appQuitOnError)"); sys.exit(code)
    while i < len(argv):
        a = argv[i]
        cmd = a[1:] if a.startswith("-") else a
        if cmd in ("headless", "stdConsole"):
            pass
        elif cmd == "silent":
            params(1)
        elif cmd == "set":
            kv = params(1)[0]; out("Executing command 'set' with parameter '%s'" % kv)
            k, v = kv.split("=", 1); st.settings[k] = v
            if k == "appQuitOnError": quit_on_error = (v.lower() == "true")
        elif cmd == "newScene":
            out("Executing command 'newScene'"); st = State(); st.settings["appQuitOnError"] = str(quit_on_error).lower()
        elif cmd == "load":
            p = params(2); path = p[0]
            out("Executing command 'load' with parameters '\"%s\"%s'" % (path, (" " + p[1]) if len(p) > 1 else ""))
            if os.path.exists(path + ".lock"):
                out("Loading Project failed after 0.001 seconds.")
                out("Processing failed: Cannot load project that is already open in another instance..\n  [0x4999\\0x5034]")
                out("Loading Project failed after 0.022 seconds."); sys.exit(E_LOCKED)   # [OBS] exits even without appQuitOnError? -> observed with it set
            if not os.path.exists(path):
                fail("project not found", E_INVALID); continue
            d = json.load(open(path))
            st = State(); st.__dict__.update(d); st.sel_images = set(st.sel_images); st.locked = set(st.locked)
            quit_on_error = st.settings.get("appQuitOnError", "false") == "true" or quit_on_error
            st.project = path
            out("Added %d images." % len(st.images)); out("Loading Project completed in 4.6 seconds."); out("Loading Project completed in 7.3 seconds.")
        elif cmd == "save":
            p = params(1); path = p[0] if p else st.project
            out("Executing command 'save' with parameter '%s'" % path)
            d = dict(st.__dict__); d["sel_images"] = sorted(st.sel_images); d["locked"] = sorted(st.locked); d["project"] = path
            json.dump(d, open(path, "w"))
            st.project = path
        elif cmd == "addFolder":
            folder = params(1)[0]; out("Executing command 'addFolder' with parameter '%s'" % folder)
            files = sorted(f for f in os.listdir(folder) if f.lower().endswith(".jpg"))
            xmp = {os.path.splitext(f)[0] for f in os.listdir(folder) if f.lower().endswith(".xmp")}
            for f in files:
                n, e = os.path.splitext(f)
                st.images.append(dict(name=n, ext=e[1:], kind="photo", x=random.uniform(-3, 3), y=random.uniform(-3, 3), z=random.uniform(1.2, 1.7), prior=(n in xmp), path=folder + os.sep))
            out("Added %d images." % len(files))
        elif cmd == "align":
            out("Executing command 'align'")
            photos = [k for k, im in enumerate(st.images) if im["kind"] == "photo"]
            lsps = [k for k, im in enumerate(st.images) if im["kind"] == "lsp"]
            if not st.comps:
                st.comps.append(photo_comp(st, "Component 0", photos, 0.6 if SCEN == "float" else 0.03)); st.selected = "Component 0"
            elif lsps:
                if SCEN == "outcome2":
                    st.comps.append(photo_comp(st, "Component 0 (1)", photos, 0.6)); st.comps.append(lsp_comp(st, "Component 1", lsps, 4.814))
                elif len(st.comps) >= 2 and st.settings.get("sfmMergeGeoreferencedComponents", "false") == "true" and all(c["georef"] == "True" for c in st.comps[:2]):
                    merged = dict(st.comps[0]); merged.update(name="Component 0", cams=photos + lsps, points=st.comps[0]["points"] + st.comps[1]["points"], mean=1.6, median=1.2, max=2.9, cps=0, metric="True")
                    st.comps = [merged]; st.selected = "Component 0"
                elif st.cps >= 3 and len(st.comps) >= 2:
                    merged = dict(st.comps[0]); merged.update(name="Component 0", cams=photos + lsps, points=st.comps[0]["points"] + st.comps[1]["points"], mean=1.7, median=1.2, max=2.9, cps=st.cps, metric="True")
                    st.comps = [merged]; st.selected = "Component 0"
                # else: nothing changes (locked photos, no measurements)  [ASSUMED]
            out("Alignment completed in 31.2 seconds.")
        elif cmd == "selectMaximalComponent":
            out("Executing command 'selectMaximalComponent'")
            if st.comps: st.selected = max(st.comps, key=lambda c: len(c["cams"]))["name"]
        elif cmd == "selectComponent":
            name = params(1)[0]; out("Executing command 'selectComponent' with parameter '%s'" % name)
            if any(c["name"] == name for c in st.comps): st.selected = name
            else: fail("component '%s' not found" % name, E_INVALID)   # [ASSUMED]
        elif cmd == "deleteSelectedComponent":
            out("Executing command 'deleteSelectedComponent'")
            st.comps = [c for c in st.comps if c["name"] != st.selected]; st.selected = st.comps[0]["name"] if st.comps else None
        elif cmd == "renameSelectedComponent":
            nm = params(1)[0]; out("Executing command 'renameSelectedComponent' with parameter '%s'" % nm)
            for c in st.comps:
                if c["name"] == st.selected: c["name"] = nm
            st.selected = nm
        elif cmd == "selectImage":
            rx, mode = (params(2) + ["set"])[:2]; out("Executing command 'selectImage' with parameters '%s %s'" % (rx, mode))
            hit = {k for k, im in enumerate(st.images) if re.fullmatch(rx, im["name"] + "." + im["ext"])}
            st.sel_images = hit if mode == "set" else (st.sel_images | hit)
        elif cmd == "deselectAllImages":
            out("Executing command 'deselectAllImages'"); st.sel_images = set()
        elif cmd == "lockPoseForContinue":
            v = params(1)[0]; out("Executing command 'lockPoseForContinue' with parameter '%s'" % v)
            if v.lower() == "true": st.locked |= st.sel_images
            else: st.locked -= st.sel_images
        elif cmd == "importLaserScan":
            p = params(2); out("Executing command 'importLaserScan' with parameters '%s'" % " ".join(p))
            if not os.path.exists(p[0]): fail("laser scan file not found", E_INVALID); continue
            mode = "fromcomponent"
            if len(p) > 1 and os.path.exists(p[1]) and "priors" in open(p[1], errors="replace").read().lower(): mode = "frompriors"
            photos = [k for k, im in enumerate(st.images) if im["kind"] == "photo"]
            if mode == "fromcomponent" and not st.comps: fail("no component to extract camera poses from", E_INVALID); continue
            base = len(st.images)
            for k in photos:
                im = st.images[k]; st.images.append(dict(name=im["name"] + "_1_color", ext="lsp", kind="lsp", x=im["x"], y=im["y"], z=im["z"], prior=True, path=os.path.dirname(os.path.abspath(p[0])) + os.sep))   # [ASSUMED] "With original files" = beside the .ply
            lc = lsp_comp(st, "Laserscan component", list(range(base, len(st.images))), 4.814 if SCEN == "lsp_float" else 0.0)
            if len(p) > 1 and os.path.exists(p[1]) and "georeferenced>yes" in open(p[1], errors="replace").read().lower().replace(" ", ""): lc["georef"] = "True"   # georef import variant
            st.comps.append(lc)
            st.selected = "Laserscan component"     # [ASSUMED] import selects the new component
            out("Added %d images." % len(photos)); out("LiDAR import completed in 58.0 seconds.")
        elif cmd == "importControlPointsMeasurements":
            p = params(2); out("Executing command 'importControlPointsMeasurements' with parameters '%s'" % " ".join(p))
            if not os.path.exists(p[0]): fail("file not found", E_INVALID); continue
            rows = [l.split(",") for l in open(p[0], errors="replace") if l.strip() and not l.startswith("#")]
            rows = [r for r in rows if len(r) >= 4 and not r[2].strip().lower().startswith("x")]
            names = {os.path.basename(im["path"] + im["name"] + "." + im["ext"]).lower() for im in st.images} | {(im["name"] + "." + im["ext"]).lower() for im in st.images}
            bad = [r[0].strip() for r in rows if os.path.basename(r[0].strip()).lower() not in names]
            for r in rows:
                nm = r[0].strip().lower(); x, y = float(r[2]), float(r[3])
                im = next((i for i in st.images if (i["name"] + "." + i["ext"]).lower() == os.path.basename(nm)), None)
                if im is not None:
                    idx = st.images.index(im); w, h = (1920, 1200) if im["kind"] == "photo" else ((240, 150) if idx % 2 else (480, 300))
                    if x < 0 or y < 0 or x > w or y > h:
                        fail("Operation failed.\n  [Coordinates of the control point '%s' are out of range. [err:18008]]\n  [0x5078]" % r[1].strip(), 2147500037 - 2 ** 32); break   # [OBS 2026-10-08]
            else:
                pass
            pts = {}
            for r in rows: pts.setdefault(r[1].strip(), set()).add("lsp" if r[0].strip().lower().endswith(".lsp") else "photo")
            if bad: out("Warning: %d measurement(s) reference images not in the project, e.g. %s" % (len(bad), bad[0]))   # [ASSUMED]
            st.cps = sum(1 for v in pts.values() if v == {"photo", "lsp"})
            out("Imported measurements for %d control points (%d usable across both blocks)." % (len(pts), st.cps))
        elif cmd == "mergeComponents":
            out("Executing command 'mergeComponents'")
            if SCEN != "outcome2" and st.cps >= 3 and len(st.comps) >= 2:
                photos = [k for k, im in enumerate(st.images) if im["kind"] == "photo"]; lsps = [k for k, im in enumerate(st.images) if im["kind"] == "lsp"]
                merged = dict(st.comps[0]); merged.update(name="Component 0", cams=photos + lsps, points=st.comps[0]["points"] + st.comps[1]["points"], mean=1.7, median=1.2, max=2.9, cps=st.cps, metric="True")
                st.comps = [merged]; st.selected = "Component 0"
        elif cmd == "exportReport":
            p = params(3); outp, tpl = p[0], p[1]
            out("Executing command 'exportReport' with parameters '%s %s'" % (outp, tpl))
            try:
                txt = evaluate(open(tpl, encoding="utf-8", errors="replace").read(), st, tpl)
                open(outp, "w", encoding="utf-8", newline="").write(txt.replace("\n", "\r\n"))
                out("Exporting Report completed in 0.05 seconds.")
            except TemplateError as e:
                open(outp, "w").close()      # [OBS] a 0-byte file is left behind
                out("error in '%s' %s" % (tpl, e))
                out("Processing failed: Invalid or corrupted input data.\n  [Translation failed.\n\nSee into the console output for more information.]\n  [0xa065\\0x5057]")
                out("Exporting Report failed after 0.025 seconds.")
                if quit_on_error: sys.exit(E_INVALID)
        elif cmd in ("setReconstructionRegionAuto", "calculateNormalModel", "unwrap", "calculateTexture"):
            params(1); out("Executing command '%s'" % cmd)
            if cmd == "calculateNormalModel":
                if not st.comps: fail("no component", E_INVALID); continue
                st.models.append("Model 1")
        elif cmd == "exportSelectedModel":
            p = params(2); out("Executing command 'exportSelectedModel' with parameter '%s'" % p[0])
            if not st.models: fail("no model selected", E_INVALID); continue
            open(p[0], "wb").write(b"FBX-FAKE")
        elif cmd == "quit":
            out("Executing command 'quit'"); sys.exit(0)
        else:
            out("Unknown command '%s'" % cmd); fail("unknown command", E_INVALID)
        i += 1
    sys.exit(0)

if __name__ == "__main__":
    main(sys.argv[1:])
