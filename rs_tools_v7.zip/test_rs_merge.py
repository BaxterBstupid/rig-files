#!/usr/bin/env python3
"""
test_rs_merge.py -- run the whole merge ladder (check, report, align, lidar, merge, mesh) against fake_rs.py in every known
scenario.  No RealityScan needed.  `python test_rs_merge.py` prints one line per case and PASS/FAIL at the end.
Each case states the expected exit code of rs_merge.py (0 PASS, 1 gate FAIL, 2 precondition/RS error, 3 GUI running)
and, where useful, a string that must appear in the output.
"""
import os, sys, subprocess, shutil, tempfile, json

HERE = os.path.dirname(os.path.abspath(__file__))
PY = sys.executable

def make_bundle(root, n=900, xmp=True):
    b = os.path.join(root, "bundle"); os.makedirs(os.path.join(b, "images"))
    for i in range(n):
        stamp = 1790187030000000000 + i * 1800000000
        open(os.path.join(b, "images", "img_%d.jpg" % stamp), "wb").close()
        if xmp: open(os.path.join(b, "images", "img_%d.xmp" % stamp), "w").write("<x:xmpmeta/>")
    open(os.path.join(b, "cloud_color.ply"), "wb").write(b"ply\n")
    return b

def make_tools(root):
    t = os.path.join(root, "tools"); os.makedirs(t)
    for f in ("rs_merge.py", "rs_gate.py", "rs_gate.html", "fake_rs.py", "cp_make.py"):
        shutil.copy(os.path.join(HERE, f), t)
    open(os.path.join(t, "lidar_import_fromcomponent.xml"), "w").write("<settings><UseCameraPoses>FromComponent</UseCameraPoses></settings>")
    open(os.path.join(t, "lidar_import_frompriors.xml"), "w").write("<settings><UseCameraPoses>FromCameraPosePriors</UseCameraPoses></settings>")
    open(os.path.join(t, "lidar_import_georef.xml"), "w").write("<settings><Georeferenced>Yes</Georeferenced><UseCameraPoses>FromComponent</UseCameraPoses></settings>")
    return t

def run(tools, bundle, out, stage, extra=(), scenario="good", env=None):
    e = dict(os.environ); e["FAKE_RS_SCENARIO"] = scenario; e["RS_EXE"] = "%s %s" % (PY, os.path.join(tools, "fake_rs.py"))
    if env: e.update(env)
    r = subprocess.run([PY, "-I", os.path.join(tools, "rs_merge.py"), bundle, out, stage, "--no-guard"] + list(extra), capture_output=True, text=True, env=e)
    return r.returncode, r.stdout + r.stderr

def main():
    root = tempfile.mkdtemp(prefix="rsladder_")
    tools, bundle = make_tools(root), make_bundle(root)
    results = []
    def case(name, rc, out, want_rc, must=""):
        ok = rc == want_rc and (must in out)
        results.append(ok)
        print("%-58s rc=%d want=%d %s" % (name, rc, want_rc, "ok" if ok else "FAIL"))
        if not ok: print("------ output ------\n" + out[-3000:] + "\n--------------------")
        return out

    # 1. the happy ladder
    out = os.path.join(root, "out_good")
    case("check", *run(tools, bundle, out, "check"), 0, "check done, rc=0")
    case("align  S1 one component, frame check ok", *run(tools, bundle, out, "align"), 0, "GATE PASS (align)")
    o = case("lidar  S2 photo+laser, no duplicates", *run(tools, bundle, out, "lidar"), 0, "GATE PASS (lidar)")
    results.append("NOTE: components differ in georeferenced/metric" in o); print("%-58s %s" % ("lidar  georef/metric asymmetry is surfaced", "ok" if results[-1] else "FAIL"))
    results.append("LSP cameras of the selected component" in o and "photo cameras of the selected component" in o)
    print("%-58s %s" % ("lidar  both frame checks present (photo + LSP)", "ok" if results[-1] else "FAIL"))
    case("merge  S3 without cps.cpm -> precondition", *run(tools, bundle, out, "merge"), 2, "missing")
    # cp_make.py: six corners clicked in 3 photos each -> cps.cpm with mirrored LSP rows, names taken from the S2 reports
    photos = sorted(f for f in os.listdir(os.path.join(bundle, "images")) if f.endswith(".jpg"))
    clicks = os.path.join(out, "cp_clicks.csv")
    with open(clicks, "w") as fh:
        fh.write("image, point, x, y\n")
        for k in range(6):
            for v in range(3): fh.write("%s, CP%d, %.1f, %.1f\n" % (photos[k * 3 + v], k + 1, 100 + 10 * k, 200 + 5 * v))
        fh.write("not_a_photo.jpg, CP7, 1, 1\n")
    r = subprocess.run([PY, "-I", os.path.join(tools, "cp_make.py"), clicks, os.path.join(out, "S2_lidar.html"), os.path.join(out, "S2b_lidar_lsp.html"), os.path.join(out, "cps.cpm")], capture_output=True, text=True)
    results.append(r.returncode == 1 and "unknown images: 1" in r.stdout); print("%-58s %s" % ("cp_make rejects a click on an unknown image (rc 1)", "ok" if results[-1] else "FAIL" + r.stdout))
    with open(clicks) as fh: lines = [l for l in fh if not l.startswith("not_a_photo")]
    open(clicks, "w").writelines(lines)
    r = subprocess.run([PY, "-I", os.path.join(tools, "cp_make.py"), clicks, os.path.join(out, "S2_lidar.html"), os.path.join(out, "S2b_lidar_lsp.html"), os.path.join(out, "cps.cpm")], capture_output=True, text=True)
    cpm = open(os.path.join(out, "cps.cpm")).read()
    results.append(r.returncode == 0 and cpm.count("_1_color.lsp,") == 18 and cpm.count(".jpg,") == 18); print("%-58s %s" % ("cp_make writes 18 photo + 18 mirrored LSP measurements", "ok" if results[-1] else "FAIL\n" + r.stdout + cpm[:400]))
    case("merge  S3 with cp_make's 6 CPs -> ONE component", *run(tools, bundle, out, "merge"), 0, "GATE PASS (merge)")
    r = subprocess.run([PY, "-I", os.path.join(tools, "cp_make.py"), clicks, os.path.join(out, "S2_lidar.html"), os.path.join(out, "S2b_lidar_lsp.html"), os.path.join(out, "cps_strict.cpm"), "--min-views", "4"], capture_output=True, text=True)
    results.append(r.returncode == 1 and "points kept: 0" in r.stdout); print("%-58s %s" % ("cp_make --min-views 4 drops 3-view points (rc 1)", "ok" if results[-1] else "FAIL " + r.stdout))
    case("mesh   S4 FBX + report", *run(tools, bundle, out, "mesh"), 0, "GATE PASS (mesh)")
    results.append(os.path.exists(os.path.join(out, "S4_room.fbx"))); print("%-58s %s" % ("mesh   S4_room.fbx written", "ok" if results[-1] else "FAIL"))
    for f in ("S1_align.rsproj", "S2_lidar.rsproj", "S3_merge.rsproj", "S4_mesh.rsproj", "S1_align.log", "S2_lidar.log", "S1_align.html", "S2a_imported.html", "S2_lidar.html", "S2b_lidar_lsp.html", "S3a_mergetool.html", "S3_merge.html", "S4_mesh.html"):
        results.append(os.path.exists(os.path.join(out, f)))
        if not results[-1]: print("missing artefact", f)

    # 2. report stage on a saved project, with and without component selection
    env = {"RS_PROJ": os.path.join(out, "S2_lidar.rsproj")}
    o = case("report S0 on S2 project, as saved", *run(tools, bundle, out, "report", env=env), 0, "GATE PASS (report)")
    o = case("report S0 with 'Component 0' selected", *run(tools, bundle, out, "report", extra=["Component 0"], env=env), 0, "photo cameras of the selected component")
    o = case("report S0 with 'Laserscan component' selected", *run(tools, bundle, out, "report", extra=["Laserscan component"], env=env), 0, "LSP cameras of the selected component")
    results.append(os.path.exists(os.path.join(out, "S0_report_Laserscan_component.html"))); print("%-58s %s" % ("report file named after the component", "ok" if results[-1] else "FAIL"))
    case("report S0 with a missing component name -> RS error", *run(tools, bundle, out, "report", extra=["Component 9"], env=env), 2, "Processing failed: component 'Component 9' not found")
    case("report S0 without RS_PROJ", *run(tools, bundle, out, "report", env={"RS_PROJ": ""}), 2, "set RS_PROJ")

    sp = os.path.join(root, "Desk top", "FIRST TRY AT REAL RENDER.rsproj"); os.makedirs(os.path.dirname(sp)); shutil.copy(os.path.join(out, "S2_lidar.rsproj"), sp)
    case("report S0 on a project path with spaces", *run(tools, bundle, out, "report", extra=["Laserscan component"], env={"RS_PROJ": sp}), 0, "GATE PASS (report)")

    # 3. the GUI lock
    open(os.path.join(out, "S2_lidar.rsproj.lock"), "w").close()
    case("report S0 while GUI holds the project -> 0x82000017", *run(tools, bundle, out, "report", env=env), 2, "already open in another instance")
    os.unlink(os.path.join(out, "S2_lidar.rsproj.lock"))

    # 4. documented outcome 2 (duplicates after align)
    out2 = os.path.join(root, "out_outcome2")
    run(tools, bundle, out2, "align", scenario="outcome2")
    case("lidar  outcome 2 -> FAIL names duplicates", *run(tools, bundle, out2, "lidar", scenario="outcome2"), 1, "duplicates = aligned more than once")

    # 4b. experiments as flags: A (no priors) and B (georef import + merge georeferenced), tagged, baseline untouched
    outA = os.path.join(root, "out_exp")
    case("align  baseline", *run(tools, bundle, outA, "align"), 0, "GATE PASS (align)")
    case("align  experiment A --no-priors -> S1_align_nopriors.*", *run(tools, bundle, outA, "align", extra=["--no-priors"]), 0, "tag=_nopriors")
    results.append(os.path.exists(os.path.join(outA, "S1_align.rsproj")) and os.path.exists(os.path.join(outA, "S1_align_nopriors.rsproj"))); print("%-58s %s" % ("experiment A did not overwrite the baseline S1", "ok" if results[-1] else "FAIL"))
    o = case("lidar  experiment A loads S1_align_nopriors", *run(tools, bundle, outA, "lidar", extra=["--no-priors"]), 0, "S2_lidar_nopriors.html")
    o = case("lidar  experiment B --merge-georef + georef params -> MERGED", *run(tools, bundle, outA, "lidar", extra=["--merge-georef", "--lidar-params", os.path.join(tools, "lidar_import_georef.xml")]), 1, "MERGED: one component holding 1800 cameras")
    results.append(os.path.exists(os.path.join(outA, "S2_lidar_georef.rsproj")) and "no 'Laserscan component' to select" in o); print("%-58s %s" % ("experiment B: project saved before the LSP selection failed", "ok" if results[-1] else "FAIL"))
    case("lidar  --merge-georef without georef params -> WARN", *run(tools, bundle, outA, "lidar", extra=["--merge-georef", "--tag", "_georef2"]), 0, "[WARN] --merge-georef without a Georeferenced=Yes params file")
    case("mesh   experiment B goes straight to S4 on the merged S2", *run(tools, bundle, outA, "mesh", extra=["--tag", "_georef"]), 0, "GATE PASS (mesh)")
    results.append(os.path.exists(os.path.join(outA, "S4_room_georef.fbx"))); print("%-58s %s" % ("experiment B: S4_room_georef.fbx written", "ok" if results[-1] else "FAIL"))

    # 4c. ADOPT: carry an existing 4-component GUI project forward instead of starting from zero
    outC = os.path.join(root, "out_adopt")
    run(tools, bundle, outC, "align", scenario="outcome2"); run(tools, bundle, outC, "lidar", scenario="outcome2")
    firsttry = os.path.join(root, "Desk top", "FIRST TRY AT REAL RENDER.rsproj"); os.makedirs(os.path.dirname(firsttry), exist_ok=True)
    shutil.copy(os.path.join(outC, "S2_lidar.rsproj"), firsttry); before = open(firsttry, "rb").read()
    o = case("adopt  picks the two originals out of four, saves a NEW file", *run(tools, bundle, outC, "adopt", env={"RS_PROJ": firsttry}), 0, "GATE PASS (lidar)")
    results.append("KEEP photo block 'Component 0'" in o and "KEEP LSP block 'Laserscan component'" in o and "DELETE ['Component 0 (1)', 'Component 1']" in o); print("%-58s %s" % ("adopt  chose by frame check, deleted the floated copies", "ok" if results[-1] else "FAIL\n" + o[-1500:]))
    results.append(open(firsttry, "rb").read() == before and os.path.exists(os.path.join(outC, "S2_lidar_adopt.rsproj"))); print("%-58s %s" % ("adopt  original project byte-identical afterwards", "ok" if results[-1] else "FAIL"))
    with open(os.path.join(outC, "cp_clicks.csv"), "w") as fh:
        fh.write("image, point, x, y\n")
        for k in range(6):
            for v in range(3): fh.write("%s, CP%d, %.1f, %.1f\n" % (photos[k * 3 + v], k + 1, 100 + 10 * k, 200 + 5 * v))
    subprocess.run([PY, "-I", os.path.join(tools, "cp_make.py"), os.path.join(outC, "cp_clicks.csv"), os.path.join(outC, "S2_lidar_adopt.html"), os.path.join(outC, "S2b_lidar_lsp_adopt.html"), os.path.join(outC, "cps.cpm")], capture_output=True, text=True)
    case("merge  --tag _adopt continues from the adopted project", *run(tools, bundle, outC, "merge", extra=["--tag", "_adopt"]), 0, "GATE PASS (merge)")
    case("mesh   --tag _adopt", *run(tools, bundle, outC, "mesh", extra=["--tag", "_adopt"]), 0, "GATE PASS (mesh)")

    # 5. floats
    out3 = os.path.join(root, "out_float")
    case("align  photo block floated 0.6 m -> FAIL", *run(tools, bundle, out3, "align", scenario="float"), 1, "photo block floated")
    out4 = os.path.join(root, "out_lspfloat")
    run(tools, bundle, out4, "align", scenario="lsp_float")
    case("lidar  LSP block 4.81 m from priors -> FAIL", *run(tools, bundle, out4, "lidar", scenario="lsp_float"), 1, "LSP block floated")

    # 6. template faults are caught with RS's own message
    bad = os.path.join(tools, "bad_guid.html")
    open(bad, "w", encoding="utf-8").write(open(os.path.join(tools, "rs_gate.html"), encoding="utf-8").read().replace("ComponentInfo(componentGUID", "ComponentInfo($(componentGUID)"))
    case("template with $(componentGUID) -> RS [line,col] error", *run(tools, bundle, out, "report", extra=["--template", bad], env=env), 2, "identifier expected but '$' found")
    nouse = os.path.join(tools, "no_using.html")
    open(nouse, "w", encoding="utf-8").write("RSGATE|v5|$(dateTime)\n$IterateComponents(COMP|$(componentName)|$(componentCamerasCount)\n)\nEND\n")
    case("template without $Using -> rejected, 0-byte report", *run(tools, bundle, out, "report", extra=["--template", nouse], env=env), 2, "needs $Using")

    # 7. stage preconditions
    out5 = os.path.join(root, "out_empty")
    case("lidar  without S1 -> precondition", *run(tools, bundle, out5, "lidar"), 2, "run the align stage first")
    case("mesh   without S3 -> precondition", *run(tools, bundle, out5, "mesh"), 2, "run the merge stage first")
    case("lidar  without params xml -> precondition", *run(tools, bundle, out5, "lidar", extra=["--lidar-params", os.path.join(tools, "nope.xml")]), 2, "export it from the LiDAR Scan Import dialog")
    b2 = make_bundle(os.path.join(root, "b2"), n=10, xmp=False)
    o = case("check  bundle without XMP -> WARN only", *run(tools, b2, out5, "check"), 0, "[WARN] XMP count 0")
    o = case("dry-run prints the command and runs nothing", *run(tools, bundle, out5, "align", extra=["--dry-run"]), 0, "DRY RUN:")

    print("\n%d checks, %d failed -> %s" % (len(results), results.count(False), "PASS" if all(results) else "FAIL"))
    shutil.rmtree(root, ignore_errors=True)
    return 0 if all(results) else 1

if __name__ == "__main__":
    sys.exit(main())
