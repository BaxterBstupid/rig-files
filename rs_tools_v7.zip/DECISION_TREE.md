# RealityScan merge — decision tree (v7, 2026-10-07). Every branch is a command that already exists.

## S2-adopt — THE FIRST MOVE: carry FIRST TRY AT REAL RENDER forward (no New Scene, no re-align, no re-bundle)
The saved GUI project already IS the documented state after step 5 (photos aligned 900/900, LSPs rendered From component, lock applied,
one F6 → two duplicates). It is the furthest any RealityScan attempt has ever got. ADR-005: it is not thrown away.
```
set "RS_PROJ=C:\Users\Shadow\Desktop\FIRST TRY AT REAL RENDER.rsproj"
python rs_merge.py %B% %O% adopt
```
adopt reports each of the four components by name (its own cameras = its own frame check), keeps the photo block and the LSP block
closest to their priors, deletes the two duplicates, renames the keepers Component 0 / Laserscan component, and saves a NEW file
`S2_lidar_adopt.rsproj`. The original is never written. Then S3 and S4 continue with `--tag _adopt`.
| result | next |
|---|---|
| PASS (two blocks, both ≤ 0.10 m) | S3 with `--tag _adopt` (clicks → cp_make → merge) |
| FAIL "LSP block floated" on the kept block too | both LSP copies are off their priors → experiment A/B below from the saved S1-equivalent is the only re-align, and it is run on copies |
| FAIL "photo block floated" | the GUI align let the photo block drift → S1 baseline headless (the one case where a fresh align is a conclusion of evidence) |
The S0/S1/S2 ladder below is the fallback, not the default.

Goal: ONE component holding ~1800 cameras (900 photos + 900 LSPs), both blocks within 0.10 m of their priors, then a mesh.
Run from `C:\rig\rs\tools` in RIGSTATION, GUI closed. `B=C:\rig\rs\rsbundle_130955_v3  O=C:\rig\rs\out_130955`.

## One-time (5 min, GUI) — export the remaining dialog settings so no stage ever waits on a dialog again
Each dialog has the same export icon used for the LiDAR params. Save into `C:\rig\rs\tools\`:
1. WORKFLOW → LiDAR Scan → set **Georeferenced = Yes**, Use camera poses = From component → export → `lidar_import_georef.xml`  (experiment B)
2. WORKFLOW → Import Metadata → Control Points → export → `cpm_import.xml`  (comma-separated, "Image, Point, X, Y", accuracy in px)
3. MESH → Export → Model (FBX) → export → `export_fbx.xml`  (texture/units options for S4)
Then: `type C:\rig\rs\tools\lidar_import_fromcomponent.xml` — paste the XML once; it lets the emulator carry the real field names.
`python rs_merge.py %B% %O% check` lists each file as [ok] or [WARN].

## S0 — read the saved project (read-only, 10 s each)
```
set "RS_PROJ=C:\Users\Shadow\Desktop\FIRST TRY AT REAL RENDER.rsproj"
python rs_merge.py %B% %O% report "Component 0"
python rs_merge.py %B% %O% report "Laserscan component"
```
| photo frame check (Component 0) | meaning | next |
|---|---|---|
| median ≤ 0.10 m | XMP priors held through the GUI align | S1 baseline |
| > 0.10 m | the GUI align let the photo block float (risk 4-A) | S1 baseline anyway — S1 uses fixed settings; its own frame check decides |
LSP frame check (Laserscan component) ≤ 0.10 m vs 4.81 m tells which of the two LSP copies floated; informational.

## S1 — photos only, fixed settings (3–6 min)
```
python rs_merge.py %B% %O% align
```
| result | meaning | next |
|---|---|---|
| PASS | one block, honest calibration, priors held | S2 |
| FAIL "expected ONE component" | photo overlap/texture gap — a capture or bundle problem, not RS | stop; `cp_prep`/`join_check` on the gap; re-bundle |
| FAIL "mean reprojection > 2.0" | fixed calibration or blur | note the number; proceed to S2 only if ≤ 2.5; otherwise bundle with free calibration (rs_bundle `CalibrationPrior=initial`) |
| FAIL "photo block floated" | priors not holding even headless | S2 anyway *with* `--lidar-params lidar_import_frompriors.xml` (LSPs from the XMP priors, not from the floated component) |
| RS error, exit ≠ 0 | read the `RS|` lines; key/params typo | fix the one line; nothing else changes |

## S2 — LiDAR in, photos locked, one align (5–10 min)
```
python rs_merge.py %B% %O% lidar
```
| result | meaning | next |
|---|---|---|
| PASS (photo + Laserscan, both ≤ 0.10 m) | the documented state: two honest blocks, ready for control points | S3 |
| "MERGED: one component ~1800 cameras" | the blocks joined by position | `python rs_merge.py %B% %O% mesh` |
| FAIL "duplicates … outcome 2" | lock + align re-created the blocks on 2.1.1 | **experiment B**: `python rs_merge.py %B% %O% lidar --merge-georef --lidar-params lidar_import_georef.xml` (writes `*_georef.*`, baseline untouched) |
| FAIL "LSP block floated" | LSPs rendered From component but solved elsewhere | **experiment A** first: `align --no-priors` then `lidar --no-priors` (photo block non-georeferenced, same kind as the LSP block) |
| FAIL "photo block floated" | lock did not hold | RealityScan 2.2 decision (its release note fixes a locked-camera alignment case); until then experiment B |
| NOTE georef/metric asymmetry + two blocks | expected on the baseline | proceed; S3 will prove or refute that CPs can bridge the two kinds |

Experiment B result table (`*_georef.*`): MERGED → `mesh --tag _georef`; still two blocks → S3 with `--tag _georef`; four → RS 2.2.
Experiment A result table (`*_nopriors.*`): both blocks ≤ 0.10 m → S3 with `--tag _nopriors`; photo block floated → priors are needed; use B.

## S3 — control points (your six corners) (2 min clicking + 3 min)
1. `cp_prep` already chose the sharp frames (`cp_picks.txt`, contact sheet). Write `%O%\cp_clicks.csv`: `image, point, x, y` — six corners (CP1–CP6), each clicked in **3 sharp photos**, pixels from the top-left (any image viewer with a pixel readout; IrfanView/Paint status bar).
2. `python cp_make.py %O%\cp_clicks.csv %O%\S2_lidar.html %O%\S2b_lidar_lsp.html %O%\cps.cpm` → 36 measurements (18 photo + 18 mirrored LSP), exit 0.
3. `python rs_merge.py %B% %O% merge` (add `--cpm-params cpm_import.xml` if exported; `--tag` if continuing an experiment).

| result | meaning | next |
|---|---|---|
| PASS | ONE component, CPs used ≥ 6, mean ≤ 3 px | S4 |
| FAIL "still 2 components" with CPs used ≥ 6 | measurements landed but RS refused the join | the asymmetry is real: rerun S2 as experiment A or B, then S3 again |
| FAIL "control points used < 6" | names in cps.cpm did not match project images | `cp_make.py --full-path` (export-style paths) and re-run; read the `RS|` import line for the count it accepted |
| FAIL "mean reprojection > 3" | a click is off | find the CP with the big residual in RS's own Selected Component report, fix that click, re-run |

## S4 — mesh (10–30 min)
```
python rs_merge.py %B% %O% mesh [--export-params export_fbx.xml] [--tag ...]
```
PASS → `S4_room.fbx` + the eye + the drift gate (one lamp, one arch, one front window, one side window, one mirror).

## Rules
- Never run a stage twice on the same tag without reading its FAIL line; experiments get their own tag automatically.
- Every RS run is in `%O%\<stage><tag>.log`; paste the `RS|` lines, never a screenshot.
- After each first real run of a stage, the emulator's `[ASSUMED]` rules for that stage are promoted or corrected (`fake_rs.py`), and `python test_rs_merge.py` is re-run; that is the only "new version" expected.
