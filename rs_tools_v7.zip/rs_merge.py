#!/usr/bin/env python3
"""
rs_merge.py  v7 -- RealityScan photo+LiDAR merge: HEADLESS, STAGED, REPORTED, GATED.  Replaces rs_merge.cmd (v1-v4).
Master 20.13.79 reference section 3 as a script; RS_FIELD_PROTOCOL.md is the checklist.

    python rs_merge.py <bundle_dir> <out_dir> <stage> [component]
    stages:  check    verify RealityScan.exe, template, params files, bundle, no GUI instance (nothing is run)
             report   gate report for the project in env RS_PROJ (read-only); [component] = select it first (frame check of that block)
             adopt    CARRY FORWARD an existing GUI project (env RS_PROJ, e.g. FIRST TRY AT REAL RENDER): report every component by
                      name, pick the photo block and the LSP block closest to their priors, delete the duplicates, rename the keepers
                      "Component 0" / "Laserscan component", save as a NEW file <out>/S2_lidar_adopt.rsproj (the original is never
                      written), gate it as S2. Then: merge --tag _adopt, mesh --tag _adopt. No New Scene, no re-align, no re-bundle.
             align    S1: new scene, photos only (XMP priors), align ONCE, report, save S1_align.rsproj
             lidar    S2: load S1, import cloud_color.ply, lock photos, align ONCE, report with Component 0 and with Laserscan selected, save
             merge    S3: load S2, import cps.cpm, Merge Components, report, align ONCE, report, save
             mesh     S4: load S3, maximal component, region auto, Normal mesh, texture, FBX, report, save
    options: --rs "<exe>"        RealityScan executable (default: env RS_EXE, else RealityScan_2.1 install path)
             --lidar-params F    params xml for the lidar stage (default lidar_import_fromcomponent.xml beside this script)
             --no-priors         align: sfmEnableCameraPrior=false (photo block NOT georeferenced by the XMP priors)   [experiment A]
             --merge-georef      lidar: sfmMergeGeoreferencedComponents=true for the S2 align; pair with a Georeferenced=Yes
                                 import params file (lidar_import_georef.xml) so both blocks are georeferenced   [experiment B]
             --cpm-params F      merge: params xml exported from the Control Points import dialog (separator/accuracy); default = RS current settings
             --export-params F   mesh: params xml exported from the model Export dialog (FBX options); default = RS current settings
             --tag T             suffix for this stage's files (S2_lidar<T>.*); experiments never overwrite the baseline.
                                 --no-priors implies _nopriors, --merge-georef implies _georef. Inputs are looked up with the
                                 tag first, then the baseline (so experiment B starts from the baseline S1).
             --dry-run           print the RealityScan command line and exit
             --no-guard          skip the running-instance check
    exit:    0 = stage PASS, 1 = gate FAIL, 2 = precondition / RealityScan error, 3 = GUI instance running

Facts this script is built on (all observed on Shadow 2026-10-07 or documented in RS help):
  * headless RS cannot load a project the GUI has open -> exit 0x82000017; the GUI must be closed first         [guard]
  * -stdConsole mirrors RS's console; -silent <dir> keeps dialogs from blocking; appQuitOnError=true makes errors exit codes
  * load takes an optional deleteAutosave so a stale autosave never raises a (blocked) prompt
  * exportReport <out.html> <template>: the template must $Using(...) each function set; GUID args are bare identifiers;
    $ExportCameras writes the APPLICATION's selected component only (template-side $SelectComponent does not switch it),
    so this script selects a component explicitly before every export that needs a frame check
  * imageName has no extension (imageExt is separate); f is in 36 mm units / 36 (0.442 = 15.9 mm)
Every RS run is logged verbatim to <out>/<stage>.log.
"""
import sys, os, re, json, shlex, argparse, subprocess, platform, time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import rs_gate

DEFAULT_RS = r"C:\Program Files\Epic Games\RealityScan_2.1\RealityScan.exe"
E_CODES = {-2113929193: "0x82000017 project already open in another instance (close the RealityScan GUI)",
           -2147024809: "0x80070057 invalid argument / template error (see the RS console lines above)",
           3: "crash (minidump written)", 0: "ok"}

def rs_cmd(opt):
    if opt.rs: return shlex.split(opt.rs, posix=(platform.system() != "Windows"))
    env = os.environ.get("RS_EXE")
    if env: return shlex.split(env, posix=(platform.system() != "Windows"))
    return [DEFAULT_RS]

def guard(opt):
    if opt.no_guard or platform.system() != "Windows": return True
    try:
        r = subprocess.run(["tasklist", "/FI", "IMAGENAME eq RealityScan.exe"], capture_output=True, text=True)
        if "RealityScan.exe" in r.stdout:
            print("[FAIL] RealityScan.exe is already running. Close the GUI (File - Exit, do not save) and re-run this stage.")
            print("       Headless RS cannot load a project the GUI holds open (0x82000017).")
            return False
    except OSError:
        pass
    return True

def run_rs(opt, args, log_path):
    cmd = rs_cmd(opt) + ["-stdConsole", "-headless", "-silent", os.path.join(opt.out, "crash"), "-set", "appQuitOnError=true"] + args
    if opt.dry_run:
        print("DRY RUN:", " ".join(('"%s"' % a) if " " in a else a for a in cmd)); return 0
    t0 = time.time()
    with open(log_path, "w", encoding="utf-8") as log:
        log.write("# " + " ".join(cmd) + "\n")
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors="replace")
        for line in p.stdout:
            sys.stdout.write("  RS| " + line); log.write(line)
        rc = p.wait()
        log.write("# exit %d after %.1f s\n" % (rc, time.time() - t0))
    meaning = E_CODES.get(rc) or E_CODES.get(rc - 2 ** 32) or {0x17: E_CODES[-2113929193], 0x57: E_CODES[-2147024809]}.get(rc & 0xFF, "error with appQuitOnError")
    print("--- RealityScan exit code %d  (%s)  %.0f s  log: %s" % (rc, meaning, time.time() - t0, log_path))
    return rc

def gate(opt, report, stage, label=""):
    if opt.dry_run: return 0
    return rs_gate.run(report, stage, os.path.join(opt.bundle, "images"), label)

def need(path, msg):
    if not os.path.exists(path):
        print("[FAIL] missing %s -- %s" % (path, msg)); sys.exit(2)

def outp(opt, name):                      # this stage's output file, tagged
    base, ext = os.path.splitext(name); return os.path.join(opt.out, base + opt.tag + ext)

def inp(opt, name, msg):                  # previous stage's file: tagged if it exists, else baseline
    base, ext = os.path.splitext(name)
    for cand in ([os.path.join(opt.out, base + opt.tag + ext)] if opt.tag else []) + [os.path.join(opt.out, name)]:
        if os.path.exists(cand):
            if cand.endswith(name) and opt.tag: print("    input: baseline %s (no %s%s%s)" % (name, base, opt.tag, ext))
            return cand
    need(os.path.join(opt.out, name), msg)

# ---------------------------------------------------------------- stages
def st_check(opt):
    rc = 0
    def ok(cond, good, bad, fatal=True):
        nonlocal rc
        print(("[ok]   " + good) if cond else (("[FAIL] " if fatal else "[WARN] ") + bad))
        if not cond and fatal: rc = 1
    exe = rs_cmd(opt)[0]
    ok(os.path.exists(exe) or opt.rs or os.environ.get("RS_EXE"), "RealityScan: %s" % " ".join(rs_cmd(opt)), "RealityScan.exe not at %s" % exe)
    ok(os.path.exists(opt.template), "template %s" % opt.template, "missing %s" % opt.template)
    ok(os.path.exists(opt.lidar_params), "lidar params %s" % opt.lidar_params, "missing %s -- export it from the LiDAR Scan Import dialog" % opt.lidar_params, fatal=False)
    for fn, why in (("lidar_import_frompriors.xml", "fallback import (From camera pose priors)"), ("lidar_import_georef.xml", "experiment B (Georeferenced=Yes)"),
                    ("cpm_import.xml", "Control Points import dialog settings"), ("export_fbx.xml", "model Export dialog settings (FBX)")):
        ok(os.path.exists(os.path.join(HERE, fn)), "optional %s" % fn, "optional %s not exported yet -- %s" % (fn, why), fatal=False)
    imgs = os.path.join(opt.bundle, "images")
    n = len([f for f in os.listdir(imgs) if f.lower().endswith(".jpg")]) if os.path.isdir(imgs) else 0
    ok(n > 0, "bundle images: %d jpg" % n, "no jpg in %s" % imgs)
    nx = len([f for f in os.listdir(imgs) if f.lower().endswith(".xmp")]) if os.path.isdir(imgs) else 0
    ok(nx == n, "bundle XMP priors: %d" % nx, "XMP count %d != jpg count %d -- S1 would align some frames without priors" % (nx, n), fatal=False)
    ok(os.path.exists(os.path.join(opt.bundle, "cloud_color.ply")), "bundle cloud_color.ply", "missing cloud_color.ply")
    ok(rs_gate.selftest_quiet(), "rs_gate selftest", "rs_gate selftest FAILED")
    ok(guard(opt), "no RealityScan instance running", "RealityScan.exe is running -- close the GUI before any stage", fatal=False)
    print("check done, rc=%d" % rc); return rc

def st_report(opt):
    proj = os.environ.get("RS_PROJ", "")
    if not proj: print("set RS_PROJ=path\\to\\project.rsproj first"); return 2
    need(proj, "project not found")
    if not guard(opt): return 3
    tag = re.sub(r"[^\w]+", "_", opt.component).strip("_") if opt.component else ""
    rep = os.path.join(opt.out, "S0_report%s.html" % ("_" + tag if tag else ""))
    args = ["-load", proj, "deleteAutosave"] + (["-selectComponent", opt.component] if opt.component else []) + ["-exportReport", rep, opt.template, "-quit"]
    if run_rs(opt, args, os.path.join(opt.out, "S0_report.log")): return 2
    return gate(opt, rep, "report", "selected=%s" % (opt.component or "as saved"))

def st_align(opt):
    if not guard(opt): return 3
    rep, proj = outp(opt, "S1_align.html"), outp(opt, "S1_align.rsproj")
    args = ["-newScene",
            "-set", "sfmMaxFeatureReprojectionError=3", "-set", "sfmEnableCameraPrior=%s" % ("false" if opt.no_priors else "true"),
            "-set", "sfmMergeGeoreferencedComponents=false", "-set", "sfmForceComponentRematch=false",
            "-addFolder", os.path.join(opt.bundle, "images"),
            "-align", "-selectMaximalComponent",
            "-exportReport", rep, opt.template,
            "-save", proj, "-quit"]
    if run_rs(opt, args, outp(opt, "S1_align.log")): return 2
    return gate(opt, rep, "align")

def st_lidar(opt):
    need(opt.lidar_params, "export it from the LiDAR Scan Import dialog first")
    if opt.merge_georef and "georef" not in os.path.basename(opt.lidar_params).lower():
        print("[WARN] --merge-georef without a Georeferenced=Yes params file (--lidar-params lidar_import_georef.xml): the LSP block will stay non-georeferenced and nothing will merge")
    s1 = inp(opt, "S1_align.rsproj", "run the align stage first")
    if not guard(opt): return 3
    cloud = os.path.join(opt.bundle, "cloud_color.ply")
    r_a, r_b, r_c = (outp(opt, n) for n in ("S2a_imported.html", "S2_lidar.html", "S2b_lidar_lsp.html"))
    s2 = outp(opt, "S2_lidar.rsproj")
    # run 1: import, lock photos, align ONCE, SAVE, then report with Component 0 selected.
    # (save before any selection: if the blocks merged, "Laserscan component" no longer exists and selecting it is an RS error)
    args = ["-load", s1, "deleteAutosave", "-selectMaximalComponent",
            "-set", "sfmMergeGeoreferencedComponents=%s" % ("true" if opt.merge_georef else "false"),
            "-importLaserScan", cloud, opt.lidar_params,
            "-exportReport", r_a, opt.template,
            "-selectComponent", "Component 0",
            "-selectImage", r".*\.[jJ][pP][gG]", "set",
            "-lockPoseForContinue", "true",
            "-deselectAllImages",
            "-align",
            "-save", s2,
            "-selectMaximalComponent", "-exportReport", r_b, opt.template,
            "-quit"]
    if run_rs(opt, args, outp(opt, "S2_lidar.log")): return 2
    rcs = [gate(opt, r_a, "lidar", "after import, before align"),
           gate(opt, r_b, "lidar", "after align, maximal component selected (photo frame check)")]
    # run 2 (tolerant): the LSP block's own frame check. Absent block = the blocks merged.
    args2 = ["-load", s2, "deleteAutosave", "-selectComponent", "Laserscan component", "-exportReport", r_c, opt.template, "-quit"]
    if run_rs(opt, args2, outp(opt, "S2b_lidar_lsp.log")):
        print("    no 'Laserscan component' to select after align -- either the blocks merged (see the report above) or the import named it differently")
    else:
        rcs.append(gate(opt, r_c, "lidar", "after align, Laserscan selected (LSP frame check)"))
    return max(rcs)

def st_merge(opt):
    cps = os.path.join(opt.out, "cps.cpm"); need(cps, "control-point measurements: make with cp_make.py (or export from the GUI)")
    s2 = inp(opt, "S2_lidar.rsproj", "run the lidar stage first")
    if not guard(opt): return 3
    r_a, r_b = outp(opt, "S3a_mergetool.html"), outp(opt, "S3_merge.html")
    args = ["-load", s2, "deleteAutosave",
            "-importControlPointsMeasurements", cps] + ([opt.cpm_params] if opt.cpm_params else []) + [
            "-mergeComponents", "-selectMaximalComponent", "-exportReport", r_a, opt.template,
            "-align", "-selectMaximalComponent", "-exportReport", r_b, opt.template,
            "-save", outp(opt, "S3_merge.rsproj"), "-quit"]
    if run_rs(opt, args, outp(opt, "S3_merge.log")): return 2
    return max(gate(opt, r_a, "merge", "after Merge Components"), gate(opt, r_b, "merge", "after align"))

def st_mesh(opt):
    cands = [os.path.join(opt.out, "S3_merge" + opt.tag + ".rsproj"), os.path.join(opt.out, "S3_merge.rsproj"), os.path.join(opt.out, "S2_lidar" + opt.tag + ".rsproj")]
    s3 = next((c for c in cands if os.path.exists(c)), None)
    if not s3: need(cands[1], "run the merge stage first (or the lidar stage with --merge-georef, whose merged S2 project is accepted here)")
    print("    input:", os.path.basename(s3), "(merged at S2, no S3)" if "S2_lidar" in s3 else "")
    if not guard(opt): return 3
    rep = outp(opt, "S4_mesh.html")
    args = ["-load", s3, "deleteAutosave", "-selectMaximalComponent",
            "-set", "mvsDefaultGroupingFactor=2.0", "-setReconstructionRegionAuto", "-calculateNormalModel",
            "-set", "MvsDoCorrectColors=true", "-set", "unwrapStyle=AdaptiveTexelSize", "-set", "unwrapMaxTexResolution=16384",
            "-unwrap", "-calculateTexture",
            "-exportSelectedModel", outp(opt, "S4_room.fbx")] + ([opt.export_params] if opt.export_params else []) + [
            "-exportReport", rep, opt.template,
            "-save", outp(opt, "S4_mesh.rsproj"), "-quit"]
    if run_rs(opt, args, outp(opt, "S4_mesh.log")): return 2
    return gate(opt, rep, "mesh")

def st_adopt(opt):
    proj = os.environ.get("RS_PROJ", "")
    if not proj: print("set RS_PROJ=path\\to\\project.rsproj first (the saved GUI project to carry forward)"); return 2
    need(proj, "project not found")
    if not guard(opt): return 3
    if not opt.tag: opt.tag = "_adopt"
    # 1. enumerate components (read-only)
    r0 = os.path.join(opt.out, "S0_adopt_list.html")
    if run_rs(opt, ["-load", proj, "deleteAutosave", "-exportReport", r0, opt.template, "-quit"], os.path.join(opt.out, "S0_adopt_list.log")): return 2
    text = re.sub(r"<[^>]+>", "\n", open(r0, encoding="utf-8", errors="replace").read())
    comps, _, _ = rs_gate.parse(text)
    names = [c["name"] for c in comps]
    print("    components in %s: %s" % (os.path.basename(proj), names))
    if not names: print("[FAIL] no components found"); return 2
    # 2. one read-only report per component (its own cameras = its own frame check)
    stats = {}
    for n in names:
        tag = re.sub(r"[^\w]+", "_", n).strip("_")
        rep = os.path.join(opt.out, "S0_adopt_%s.html" % tag)
        if run_rs(opt, ["-load", proj, "deleteAutosave", "-selectComponent", n, "-exportReport", rep, opt.template, "-quit"], os.path.join(opt.out, "S0_adopt_%s.log" % tag)):
            print("    could not report %s" % n); continue
        _, cams, _ = rs_gate.parse(re.sub(r"<[^>]+>", "\n", open(rep, encoding="utf-8", errors="replace").read()))
        kinds = {}
        for c in cams:
            if c["prior3d"] == c["prior3d"]: kinds.setdefault(rs_gate.kind_of(c["name"]), []).append(c["prior3d"])
        kind = max(kinds, key=lambda k: len(kinds[k])) if kinds else "other"
        med = sorted(kinds[kind])[len(kinds[kind]) // 2] if kinds else float("nan")
        stats[n] = (kind, med, len(cams))
        print("    %-24s %-5s cameras %4d  priorError3D median %s m" % (n, kind, len(cams), ("%.3f" % med) if med == med else "n/a"))
    def pick(kind):
        cand = [(stats[n][1] if stats[n][1] == stats[n][1] else 1e9, "(" in n, n) for n in stats if stats[n][0] == kind]
        return sorted(cand)[0][2] if cand else None
    keep_photo, keep_lsp = pick("photo"), pick("LSP")
    if not keep_photo or not keep_lsp:
        print("[FAIL] need one photo block and one LSP block to adopt (found photo=%s lsp=%s)" % (keep_photo, keep_lsp)); return 2
    drop = [n for n in names if n not in (keep_photo, keep_lsp)]
    print("    KEEP photo block %r (%.3f m)  KEEP LSP block %r (%.3f m)  DELETE %s" % (keep_photo, stats[keep_photo][1], keep_lsp, stats[keep_lsp][1], drop))
    # 3. write a NEW project: delete duplicates, canonical names, save-as, then report both blocks
    s2 = outp(opt, "S2_lidar.rsproj"); r_b, r_c = outp(opt, "S2_lidar.html"), outp(opt, "S2b_lidar_lsp.html")
    args = ["-load", proj, "deleteAutosave"]
    for n in drop: args += ["-selectComponent", n, "-deleteSelectedComponent"]
    if keep_photo != "Component 0": args += ["-selectComponent", keep_photo, "-renameSelectedComponent", "Component 0"]
    if keep_lsp != "Laserscan component": args += ["-selectComponent", keep_lsp, "-renameSelectedComponent", "Laserscan component"]
    args += ["-save", s2, "-selectComponent", "Component 0", "-exportReport", r_b, opt.template,
             "-selectComponent", "Laserscan component", "-exportReport", r_c, opt.template, "-quit"]
    if run_rs(opt, args, outp(opt, "S2_lidar.log")): return 2
    print("    adopted -> %s  (original %s untouched)" % (os.path.basename(s2), os.path.basename(proj)))
    return max(gate(opt, r_b, "lidar", "adopted, Component 0 selected (photo frame check)"), gate(opt, r_c, "lidar", "adopted, Laserscan selected (LSP frame check)"))

STAGES = {"check": st_check, "report": st_report, "adopt": st_adopt, "align": st_align, "lidar": st_lidar, "merge": st_merge, "mesh": st_mesh}

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("bundle"); ap.add_argument("out"); ap.add_argument("stage", choices=sorted(STAGES)); ap.add_argument("component", nargs="?", default="")
    ap.add_argument("--rs", default=""); ap.add_argument("--lidar-params", default=os.path.join(HERE, "lidar_import_fromcomponent.xml"))
    ap.add_argument("--template", default=os.path.join(HERE, "rs_gate.html"))
    ap.add_argument("--no-priors", action="store_true"); ap.add_argument("--merge-georef", action="store_true"); ap.add_argument("--tag", default=None)
    ap.add_argument("--cpm-params", default=""); ap.add_argument("--export-params", default="")
    ap.add_argument("--dry-run", action="store_true"); ap.add_argument("--no-guard", action="store_true")
    opt = ap.parse_intermixed_args()   # positional [component] may follow option flags
    opt.bundle, opt.out = os.path.abspath(opt.bundle), os.path.abspath(opt.out)
    if opt.tag is None: opt.tag = "_nopriors" if opt.no_priors else ("_georef" if opt.merge_georef else "")
    os.makedirs(os.path.join(opt.out, "crash"), exist_ok=True)
    print("=== rs_merge v7  stage=%s%s  bundle=%s  out=%s" % (opt.stage, (" tag=" + opt.tag) if opt.tag else "", opt.bundle, opt.out))
    sys.exit(STAGES[opt.stage](opt))

if __name__ == "__main__":
    main()
