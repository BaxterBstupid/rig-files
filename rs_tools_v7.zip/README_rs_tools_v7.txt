rs_tools v7 (2026-10-07) -- RealityScan photo+LiDAR merge, headless, staged, gated.  Replaces rs_merge.cmd.

INSTALL (Shadow, RIGSTATION prompt):
    cd C:\rig\rs\tools
    tar -xf %USERPROFILE%\Downloads\rs_tools_v7.zip        (overwrites rs_gate.py / rs_gate.html; the .cmd is no longer used)
    python test_rs_merge.py                                 (57 checks against the emulator -> PASS, ~5 s, no RealityScan involved)
    python rs_merge.py C:\rig\rs\rsbundle_130955_v3 C:\rig\rs\out_130955 check

RUN (one line per stage; RealityScan GUI must be closed):
    set "RS_PROJ=C:\Users\Shadow\Desktop\FIRST TRY AT REAL RENDER.rsproj"
    python rs_merge.py C:\rig\rs\rsbundle_130955_v3 C:\rig\rs\out_130955 report "Component 0"
    python rs_merge.py C:\rig\rs\rsbundle_130955_v3 C:\rig\rs\out_130955 report "Laserscan component"
    python rs_merge.py C:\rig\rs\rsbundle_130955_v3 C:\rig\rs\out_130955 align
    python rs_merge.py C:\rig\rs\rsbundle_130955_v3 C:\rig\rs\out_130955 lidar
    (cps.cpm into out_130955)  python rs_merge.py ... merge
    python rs_merge.py ... mesh
Every stage: RS console mirrored as "RS|" lines and saved to <out>\<stage>.log; report .html; PASS/FAIL with numbers.
Exit codes: 0 PASS, 1 gate FAIL, 2 precondition or RealityScan error, 3 GUI running.
    --dry-run   prints the exact RealityScan command line without running it
    --lidar-params lidar_import_frompriors.xml   fallback import if the S1 frame check fails

FILES
    rs_merge.py        driver (stages check/report/align/lidar/merge/mesh)
    rs_gate.py         gate: report -> PASS/FAIL  (python rs_gate.py --selftest)
    rs_gate.html       report template ($Using x4, bare componentGUID args, CAM|name.ext|x|y|z|priorError3D|f)
    fake_rs.py         RealityScan 2.1.1 emulator built from observed behaviour (for tests only; never run on Shadow as RS)
    test_rs_merge.py   end-to-end ladder tests against the emulator (scenarios: good, outcome2, float, lsp_float, GUI lock, template faults)
    lidar_import_fromcomponent.xml / lidar_import_frompriors.xml  -- exported from the GUI dialog (already in C:\rig\rs\tools)

v6 additions
    DECISION_TREE.md   every S0-S4 outcome -> one existing command (experiments A/B are flags, tagged, baseline never overwritten)
    cp_make.py         cp_clicks.csv (image, point, x, y on photos) -> cps.cpm with mirrored LSP rows, names taken from the S2 reports
    rs_merge.py flags  --no-priors (A), --merge-georef (B), --tag, --cpm-params, --export-params
    lidar stage        saves BEFORE any selection; LSP frame check is a separate tolerant run (a merged result no longer kills the stage)
    rs_gate.html v6    CAM lines carry imagePath (for cp_make.py)

v7: `adopt` stage -- carries the saved GUI project (FIRST TRY AT REAL RENDER) forward as S2 instead of rebuilding S1/S2 from a New Scene.
    Reads every component, keeps the two closest to their priors, deletes duplicates, saves a NEW file; the original is never written.
    This is the ADR-005 rule: the RealityScan project is the unit of progress; a fresh align is a conclusion of evidence, never a default.
    After install, tools are updated IN PLACE under the same names; the zip is the only download, ever.
