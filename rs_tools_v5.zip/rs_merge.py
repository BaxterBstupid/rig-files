#!/usr/bin/env python3
"""
rs_merge.py  v5 -- RealityScan photo+LiDAR merge: HEADLESS, STAGED, REPORTED, GATED.  Replaces rs_merge.cmd (v1-v4).
Master 20.13.79 reference section 3 as a script; RS_FIELD_PROTOCOL.md is the checklist.

    python rs_merge.py <bundle_dir> <out_dir> <stage> [component]
    stages:  check    verify RealityScan.exe, template, params files, bundle, no GUI instance (nothing is run)
             report   gate report for the project in env RS_PROJ (read-only); [component] = select it first (frame check of that block)
             align    S1: new scene, photos only (XMP priors), align ONCE, report, save S1_align.rsproj
             lidar    S2: load S1, import cloud_color.ply, lock photos, align ONCE, report with Component 0 and with Laserscan selected, save
             merge    S3: load S2, import cps.cpm, Merge Components, report, align ONCE, report, save
             mesh     S4: load S3, maximal component, region auto, Normal mesh, texture, FBX, report, save
    options: --rs "<exe>"        RealityScan executable (default: env RS_EXE, else RealityScan_2.1 install path)
             --lidar-params F    params xml for the lidar stage (default lidar_import_fromcomponent.xml beside this script)
             --dry-run           print the RealityScan command line and exit
             --no-guard          skip the running-instance check
    exit:    0 = stage PASS, 1 = gate FAIL, 2 = precondition / RealityScan error, 3 = GUI instance running

Facts this script is built on (all observed on Shadow 2026-10-07 or documented in RS help):
  * headless RS cannot load a project the GUI has open -> exit 0x82000017; the GUI must be closed first         [guard]
  * -stdConsole mirrors RS's console; -silent <dir> keeps dialogs from blocking; appQuitOnError=true makes errors exit codes
  * load takes an optional deleteAutosave so a stale autosave never raises a (blocked) prompt
  * exportReport <out.html> <template>: the template must $Using(...) each function set; GUID args are bare identifiers;
    $ExportCameras writes the APPLICATION's selected component only (template-side $SelectComponent does not switch it),
    so this script selects a component explicitly before every export that needs a frame check
  * imageName has no extension (imageExt is separate); f is in 36 mm units / 36 (0.442 = 15.9 mm)
Every RS run is logged verbatim to <out>/<stage>.log.
"""
import sys, os, re, json, shlex, argparse, subprocess, platform, time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import rs_gate

DEFAULT_RS = r"C:\Program Files\Epic Games\RealityScan_2.1\RealityScan.exe"
E_CODES = {-2113929193: "0x82000017 project already open in another instance (close the RealityScan GUI)",
           -2147024809: "0x80070057 invalid argument / template error (see the RS console lines above)",
           3: "crash (minidump written)", 0: "ok"}

def rs_cmd(opt):
    if opt.rs: return shlex.split(opt.rs, posix=(platform.system() != "Windows"))
    env = os.environ.get("RS_EXE")
    if env: return shlex.split(env, posix=(platform.system() != "Windows"))
    return [DEFAULT_RS]

def guard(opt):
    if opt.no_guard or platform.system() != "Windows": return True
    try:
        r = subprocess.run(["tasklist", "/FI", "IMAGENAME eq RealityScan.exe"], capture_output=True, text=True)
        if "RealityScan.exe" in r.stdout:
            print("[FAIL] RealityScan.exe is already running. Close the GUI (File - Exit, do not save) and re-run this stage.")
            print("       Headless RS cannot load a project the GUI holds open (0x82000017).")
            return False
    except OSError:
        pass
    return True

def run_rs(opt, args, log_path):
    cmd = rs_cmd(opt) + ["-stdConsole", "-headless", "-silent", os.path.join(opt.out, "crash"), "-set", "appQuitOnError=true"] + args
    if opt.dry_run:
        print("DRY RUN:", " ".join(('"%s"' % a) if " " in a else a for a in cmd)); return 0
    t0 = time.time()
    with open(log_path, "w", encoding="utf-8") as log:
        log.write("# " + " ".join(cmd) + "\n")
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors="replace")
        for line in p.stdout:
            sys.stdout.write("  RS| " + line); log.write(line)
        rc = p.wait()
        log.write("# exit %d after %.1f s\n" % (rc, time.time() - t0))
    meaning = E_CODES.get(rc) or E_CODES.get(rc - 2 ** 32) or {0x17: E_CODES[-2113929193], 0x57: E_CODES[-2147024809]}.get(rc & 0xFF, "error with appQuitOnError")
    print("--- RealityScan exit code %d  (%s)  %.0f s  log: %s" % (rc, meaning, time.time() - t0, log_path))
    return rc

def gate(opt, report, stage, label=""):
    if opt.dry_run: return 0
    return rs_gate.run(report, stage, os.path.join(opt.bundle, "images"), label)

def need(path, msg):
    if not os.path.exists(path):
        print("[FAIL] missing %s -- %s" % (path, msg)); sys.exit(2)

# ---------------------------------------------------------------- stages
def st_check(opt):
    rc = 0
    def ok(cond, good, bad, fatal=True):
        nonlocal rc
        print(("[ok]   " + good) if cond else (("[FAIL] " if fatal else "[WARN] ") + bad))
        if not cond and fatal: rc = 1
    exe = rs_cmd(opt)[0]
    ok(os.path.exists(exe) or opt.rs or os.environ.get("RS_EXE"), "RealityScan: %s" % " ".join(rs_cmd(opt)), "RealityScan.exe not at %s" % exe)
    ok(os.path.exists(opt.template), "template %s" % opt.template, "missing %s" % opt.template)
    ok(os.path.exists(opt.lidar_params), "lidar params %s" % opt.lidar_params, "missing %s -- export it from the LiDAR Scan Import dialog" % opt.lidar_params, fatal=False)
    imgs = os.path.join(opt.bundle, "images")
    n = len([f for f in os.listdir(imgs) if f.lower().endswith(".jpg")]) if os.path.isdir(imgs) else 0
    ok(n > 0, "bundle images: %d jpg" % n, "no jpg in %s" % imgs)
    nx = len([f for f in os.listdir(imgs) if f.lower().endswith(".xmp")]) if os.path.isdir(imgs) else 0
    ok(nx == n, "bundle XMP priors: %d" % nx, "XMP count %d != jpg count %d -- S1 would align some frames without priors" % (nx, n), fatal=False)
    ok(os.path.exists(os.path.join(opt.bundle, "cloud_color.ply")), "bundle cloud_color.ply", "missing cloud_color.ply")
    ok(rs_gate.selftest_quiet(), "rs_gate selftest", "rs_gate selftest FAILED")
    ok(guard(opt), "no RealityScan instance running", "RealityScan.exe is running -- close the GUI before any stage", fatal=False)
    print("check done, rc=%d" % rc); return rc

def st_report(opt):
    proj = os.environ.get("RS_PROJ", "")
    if not proj: print("set RS_PROJ=path\\to\\project.rsproj first"); return 2
    need(proj, "project not found")
    if not guard(opt): return 3
    tag = re.sub(r"[^\w]+", "_", opt.component).strip("_") if opt.component else ""
    rep = os.path.join(opt.out, "S0_report%s.html" % ("_" + tag if tag else ""))
    args = ["-load", proj, "deleteAutosave"] + (["-selectComponent", opt.component] if opt.component else []) + ["-exportReport", rep, opt.template, "-quit"]
    if run_rs(opt, args, os.path.join(opt.out, "S0_report.log")): return 2
    return gate(opt, rep, "report", "selected=%s" % (opt.component or "as saved"))

def st_align(opt):
    if not guard(opt): return 3
    rep, proj = os.path.join(opt.out, "S1_align.html"), os.path.join(opt.out, "S1_align.rsproj")
    args = ["-newScene",
            "-set", "sfmMaxFeatureReprojectionError=3", "-set", "sfmEnableCameraPrior=true",
            "-set", "sfmMergeGeoreferencedComponents=false", "-set", "sfmForceComponentRematch=false",
            "-addFolder", os.path.join(opt.bundle, "images"),
            "-align", "-selectMaximalComponent",
            "-exportReport", rep, opt.template,
            "-save", proj, "-quit"]
    if run_rs(opt, args, os.path.join(opt.out, "S1_align.log")): return 2
    return gate(opt, rep, "align")

def st_lidar(opt):
    need(opt.lidar_params, "export it from the LiDAR Scan Import dialog first")
    s1 = os.path.join(opt.out, "S1_align.rsproj"); need(s1, "run the align stage first")
    if not guard(opt): return 3
    cloud = os.path.join(opt.bundle, "cloud_color.ply")
    r_a, r_b, r_c = (os.path.join(opt.out, n) for n in ("S2a_imported.html", "S2_lidar.html", "S2b_lidar_lsp.html"))
    args = ["-load", s1, "deleteAutosave", "-selectMaximalComponent",
            "-importLaserScan", cloud, opt.lidar_params,
            "-exportReport", r_a, opt.template,
            "-selectComponent", "Component 0",
            "-selectImage", r".*\.[jJ][pP][gG]", "set",
            "-lockPoseForContinue", "true",
            "-deselectAllImages",
            "-align",
            "-selectComponent", "Component 0", "-exportReport", r_b, opt.template,
            "-selectComponent", "Laserscan component", "-exportReport", r_c, opt.template,
            "-save", os.path.join(opt.out, "S2_lidar.rsproj"), "-quit"]
    if run_rs(opt, args, os.path.join(opt.out, "S2_lidar.log")): return 2
    rcs = [gate(opt, r_a, "lidar", "after import, before align"),
           gate(opt, r_b, "lidar", "after align, Component 0 selected (photo frame check)"),
           gate(opt, r_c, "lidar", "after align, Laserscan selected (LSP frame check)")]
    return max(rcs)

def st_merge(opt):
    cps = os.path.join(opt.out, "cps.cpm"); need(cps, "control-point measurements: export from the GUI or make with cp_make.py")
    s2 = os.path.join(opt.out, "S2_lidar.rsproj"); need(s2, "run the lidar stage first")
    if not guard(opt): return 3
    r_a, r_b = os.path.join(opt.out, "S3a_mergetool.html"), os.path.join(opt.out, "S3_merge.html")
    args = ["-load", s2, "deleteAutosave",
            "-importControlPointsMeasurements", cps,
            "-mergeComponents", "-selectMaximalComponent", "-exportReport", r_a, opt.template,
            "-align", "-selectMaximalComponent", "-exportReport", r_b, opt.template,
            "-save", os.path.join(opt.out, "S3_merge.rsproj"), "-quit"]
    if run_rs(opt, args, os.path.join(opt.out, "S3_merge.log")): return 2
    return max(gate(opt, r_a, "merge", "after Merge Components"), gate(opt, r_b, "merge", "after align"))

def st_mesh(opt):
    s3 = os.path.join(opt.out, "S3_merge.rsproj"); need(s3, "run the merge stage first")
    if not guard(opt): return 3
    rep = os.path.join(opt.out, "S4_mesh.html")
    args = ["-load", s3, "deleteAutosave", "-selectMaximalComponent",
            "-set", "mvsDefaultGroupingFactor=2.0", "-setReconstructionRegionAuto", "-calculateNormalModel",
            "-set", "MvsDoCorrectColors=true", "-set", "unwrapStyle=AdaptiveTexelSize", "-set", "unwrapMaxTexResolution=16384",
            "-unwrap", "-calculateTexture",
            "-exportSelectedModel", os.path.join(opt.out, "S4_room.fbx"),
            "-exportReport", rep, opt.template,
            "-save", os.path.join(opt.out, "S4_mesh.rsproj"), "-quit"]
    if run_rs(opt, args, os.path.join(opt.out, "S4_mesh.log")): return 2
    return gate(opt, rep, "mesh")

STAGES = {"check": st_check, "report": st_report, "align": st_align, "lidar": st_lidar, "merge": st_merge, "mesh": st_mesh}

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("bundle"); ap.add_argument("out"); ap.add_argument("stage", choices=sorted(STAGES)); ap.add_argument("component", nargs="?", default="")
    ap.add_argument("--rs", default=""); ap.add_argument("--lidar-params", default=os.path.join(HERE, "lidar_import_fromcomponent.xml"))
    ap.add_argument("--template", default=os.path.join(HERE, "rs_gate.html"))
    ap.add_argument("--dry-run", action="store_true"); ap.add_argument("--no-guard", action="store_true")
    opt = ap.parse_intermixed_args()   # positional [component] may follow option flags
    opt.bundle, opt.out = os.path.abspath(opt.bundle), os.path.abspath(opt.out)
    os.makedirs(os.path.join(opt.out, "crash"), exist_ok=True)
    print("=== rs_merge v5  stage=%s  bundle=%s  out=%s" % (opt.stage, opt.bundle, opt.out))
    sys.exit(STAGES[opt.stage](opt))

if __name__ == "__main__":
    main()
